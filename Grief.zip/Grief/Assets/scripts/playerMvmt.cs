﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
public class playerMvmt : MonoBehaviour
{
    public LayerMask canBeClickedOn;
    private NavMeshAgent myAgent;
     void Start()
    {
        myAgent = GetComponent<NavMeshAgent>();
    }
    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Ray myRay = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hitInfo;

            if(Physics.Raycast(myRay, out hitInfo, 100, canBeClickedOn))
            {
                myAgent.SetDestination(hitInfo.point);
            }
        }
    }
}
