﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ctrl_Camera : MonoBehaviour
{
    public Vector3 p; 
    
 
//Vector3 pos = Camera.main.ScreenToWorldPoint(p);
   // testGameObject.transform.position = pos;
    // Start is called before the first frame update
    void Start()
    {
       
    }

    // Update is called once per frame
    void Update()
    {
        p = Input.mousePosition;
        
        
  
        //Input.mouseScrollDelta.y
        if (p.x >= Screen.width*0.75)
        { camRight();
        }
        if (p.x <= Screen.width * 0.15)
        {
        camLeft();
        }
        //Debug.Log(Input.GetAxis("Mouse ScrollWheel"));

        if (Input.GetAxis("Mouse ScrollWheel") > 0f && GetComponent<Camera>().fieldOfView < 25) // forward
        {
            GetComponent<Camera>().fieldOfView++;
        }
        else if (Input.GetAxis("Mouse ScrollWheel") < 0f && GetComponent<Camera>().fieldOfView > 15) // backwards
        {
            GetComponent<Camera>().fieldOfView--;
        }

    }
    void camRight()
    {
       
        if (transform.position.x <= 10){
            GetComponent<Transform>().Translate(new Vector3(0.1f, 0, 0));
            // GetComponent<Transform>().Rotate(new Vector3(0, -0.1f, 0));
            //  GetComponent<Camera>().FieldOfView()++;
            
        }
    }
void camLeft()
{
    if (transform.position.x >= -13)
    {
        GetComponent<Transform>().Translate(new Vector3(-0.1f, 0, 0));
            //GetComponent<Transform>().Rotate(new Vector3(0, 0.1f, 0));
            

        }

        
    }
}
