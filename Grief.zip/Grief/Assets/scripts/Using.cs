﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Using : MonoBehaviour
{
    public GameObject destroyedPrefab;
    public GameObject neededObject;
    public GameObject dropObject;

    // Start is called before the first frame update
    void OnMouseDown()
    {
 
        
    }

        void OnCollisionEnter(Collision collision)
        {
            if(collision.gameObject.tag == "avatar")
            {
             if (GameObject.FindWithTag("Held") == neededObject)
                {
                Instantiate(destroyedPrefab, transform.position, transform.rotation);
                Destroy(gameObject);
                destroyedPrefab.tag = "Destroyed";
                Destroy(GameObject.FindWithTag("Destroyed"), 3);
                }
        }
        }
    }