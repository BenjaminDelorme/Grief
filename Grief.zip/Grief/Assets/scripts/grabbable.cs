﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class grabbable : MonoBehaviour
{
    public GameObject grabButton;
    public GameObject leaveButton;
    public GameObject foundText;
    public int layer;
    float dist;
    //public GameObject canvasData; 
    //Text txt;
    private void Start()
    {
        layer = GameObject.Find("Hitbox").GetComponent<playerMvmt>().canBeClickedOn;
        grabButton = GameObject.Find("grabButton");
        leaveButton = GameObject.Find("leaveButton");
        foundText = GameObject.Find("foundObject");
        GetComponent<Renderer>().material.SetColor("_Color", Color.white);
        //grabButton.SetActive(false);
        // leaveButton.SetActive(false);
        //foundText.SetActive(false);
        GameObject.Find("Canvas").GetComponent<CanvasGroup>().alpha = 0f;
        GameObject.Find("Canvas").GetComponent<CanvasGroup>().blocksRaycasts = false;
    }

    private void Update()
    {
        Debug.Log("Holding "+ GameObject.FindWithTag("Held"));
       // dist = Vector3.Distance(GameObject.Find("Hitbox").GetComponent<Transform>().position, transform.position);
       // Debug.Log(dist);
       // if (dist > 5) 
       // {
         //   GameObject.Find("Canvas").GetComponent<CanvasGroup>().alpha = 0f;
         //   GameObject.Find("Canvas").GetComponent<CanvasGroup>().blocksRaycasts = false;
         //   GameObject.Find("Hitbox").GetComponent<playerMvmt>().canBeClickedOn = 256;
        //}
    }
    void OnMouseEnter()

    {
        GetComponent<Renderer>().material.SetColor("_Color", Color.red);

        //startcolor = renderer.material.color;
        //renderer.material.color = Color.red;
    }
    void OnMouseExit()
    {
        GetComponent<Renderer>().material.SetColor("_Color", Color.white);

        //renderer.material.color = startcolor;
    }


    void OnCollisionEnter(Collision collision)
    {
       

        if (collision.gameObject.tag == "avatar")
        {

            if (GameObject.Find("Char").tag == "Holding")
           {
               GameObject.Find("LeaveBText").GetComponent<Text>().text = "Keep";
                //Debug.Log("oiii");
           }




            //GameObject.Find("grabButton").SetActive(true);

            //canvasGroup.alpha = 0f; //this makes everything transparent
            // canvasGroup.blocksRaycasts = false; //this prevents the UI element to receive input events

            //grabButton.SetActive(true);
            //leaveButton.SetActive(true);
            //foundText.SetActive(true);
            GameObject.Find("Canvas").GetComponent<CanvasGroup>().alpha = 1f;
            GameObject.Find("Canvas").GetComponent<CanvasGroup>().blocksRaycasts = true;
            GameObject.Find("foundObject").GetComponent<Text>().text = gameObject.name;
            GameObject.Find("Hitbox").GetComponent<playerMvmt>().canBeClickedOn = 0;
            
           // else if (GameObject.Find("Char").tag == "Holding")
            //{
              //  leaveButton.GetComponent<Text>().text = "Keep";
        
           // }
            grabButton.GetComponent<Button>().onClick.AddListener(GrabOnClick);
            leaveButton.GetComponent<Button>().onClick.AddListener(LeaveOnClick);
            

        }
        // GetComponent<Renderer>().material.SetColor("_Color", Color.black);
        // transform.parent = GameObject.Find("Hitbox").transform;
        //Debug.Log(layer);

    }
    public void GrabOnClick()
    {

        if(GameObject.Find("Char").tag == "Holding")
            {
            GameObject.FindWithTag("Held").GetComponent<Renderer>().enabled = true;
            GameObject.FindWithTag("Held").GetComponent<Collider>().enabled = true;
            GameObject.FindWithTag("Held").GetComponent<Rigidbody>().isKinematic = false;
            // GameObject.Find("LeaveBText").GetComponent<Text>().text = "Keep";
            Debug.Log("bye");
            GameObject.FindWithTag("Held").transform.parent = null;
            //GameObject.FindWithTag("Held").GetComponent<Transform>().Translate(new Vector3(0, 2, 0));
            GameObject.FindWithTag("Held").tag = "Untagged";
            

            //transform.parent = null;
        }

        GetComponent<Renderer>().material.SetColor("_Color", Color.black);
        // GetComponent<Transform>().Translate(new Vector3(0, 2, 0));
        transform.parent = GameObject.Find("Hitbox").transform;
        //grabButton.SetActive(false);
        //leaveButton.SetActive(false);
        //foundText.SetActive(false);
        GameObject.Find("HeldItemText").GetComponent<Text>().text = gameObject.name;
        gameObject.tag = "Held";
        gameObject.GetComponent<Renderer>().enabled = false;
        gameObject.GetComponent<Collider>().enabled = false;
        gameObject.GetComponent<Rigidbody>().isKinematic = true;


        //gameObject.GetComponent<Transform>().Translate(GameObject.Find("Char").GetComponent<Transform>().position);
        GameObject.Find("Char").tag = "Holding";

        GameObject.Find("Canvas").GetComponent<CanvasGroup>().alpha = 0f;
        GameObject.Find("Canvas").GetComponent<CanvasGroup>().blocksRaycasts = false;
        GameObject.Find("Hitbox").GetComponent<playerMvmt>().canBeClickedOn = 256;
        //Debug.Log(layer);
    }
    public void LeaveOnClick()
    {
        // grabButton.SetActive(false);
        //leaveButton.SetActive(false);
        //foundText.SetActive(false);
        GameObject.Find("Canvas").GetComponent<CanvasGroup>().alpha = 0f;
        GameObject.Find("Canvas").GetComponent<CanvasGroup>().blocksRaycasts = false;
        GameObject.Find("Hitbox").GetComponent<playerMvmt>().canBeClickedOn = 256;

    }
}
