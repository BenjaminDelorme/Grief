﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class testDistance : MonoBehaviour
{
    
        public Transform other;
    float dist;

 
    private void Update()
    {
        dist = Vector3.Distance(other.position, transform.position);
      //  Debug.Log(dist);
        gameObject.GetComponent<Renderer>().material.SetColor("_Color", Color.red);
    }

}
